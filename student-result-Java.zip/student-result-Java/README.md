# student-result-system-in-Java-OOP
This video demonstrates a simple result management system developed in Java language.
 Change the database connections to your preffered Mysql Database connection.
 
 
 And Have fun Thanks................
